
letters = [
"a","á","ä","b","c","č","d","ď","dz","dž","e","é","f","g","h","ch",
"i","í","j","k","l","ĺ","ľ","m","n","ň","o","ó","ô","p","q","r","ŕ",
"s","š","t","ť","u","ú","v","w","x","y","ý","z","ž"
]

numbers = [str(i+1) for i in range(len(letters))]

encode_dict = dict(zip(letters, numbers))
decode_dict = dict(zip(numbers, letters))


def encode(text):
    text = text.lower()
    words = text.split(" ")
    encoded_words = []

    for word in words:
        i = 0
        encoded_letters = []

        while i < len(word):

            
            if word[i:i+2] == "dž":
                encoded_letters.append(encode_dict["dž"])
                i += 2
                continue

            
            if word[i:i+2] == "dz":
                encoded_letters.append(encode_dict["dz"])
                i += 2
                continue

            
            if word[i:i+2] == "ch":
                encoded_letters.append(encode_dict["ch"])
                i += 2
                continue

            letter = word[i]

            if letter in encode_dict:
                encoded_letters.append(encode_dict[letter])

            i += 1

        encoded_words.append("-".join(encoded_letters))

    return " : ".join(encoded_words)


def decode(code):
    words = code.split(" : ")
    decoded_words = []

    for word in words:
        nums = word.split("-")
        letters_word = []

        for n in nums:
            if n in decode_dict:
                letters_word.append(decode_dict[n])

        decoded_words.append("".join(letters_word))

    return " ".join(decoded_words)


while True:
    mode = input("encode / decode / exit: ")

    if mode == "encode":
        text = input("text: ")
        print(encode(text))

    elif mode == "decode":
        code = input("code: ")
        print(decode(code))

    elif mode == "exit":
        break

    