import tkinter as tk
import subprocess
import os
import sys

root = tk.Tk()
root.title("Launcher V1")
root.geometry("400x200")


launcher_dir = os.path.dirname(os.path.abspath(__file__))

def resource_path(relative_path):    
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


icon_path = os.path.join(launcher_dir, "icons", "L.Decoder.ico")
try:
    root.iconbitmap(icon_path)
except tk.TclError:
    print("Icon not found")

def open_version(file_name):
    file_path = os.path.join(launcher_dir, file_name)
    if os.path.exists(file_path):
        subprocess.Popen(["python", file_path])
    else:
        print(f"File {file_path} is not found bruh")


def open_readme():
    readme_path = os.path.join(launcher_dir, "README.txt")
    if os.path.exists(readme_path):
        os.startfile(readme_path)  
    else:
        print(f"File {readme_path} not found ahh")


tk.Label(root, text="Choose a version:").pack(pady=10)

tk.Button(root, text="Decoder BETA (CMD version)", width=25,    
           command=lambda: open_version("Language-Decoder-CMD-beta.py")).pack(pady=5)

tk.Button(root, text="Decoder V1 (CMD version)", width=25,
          command=lambda: open_version("Language-Decoder-CMD-V1.py")).pack(pady=5)


tk.Button(root, text="Decoder V2 (With GUI.1)", width=25,
           command=lambda: open_version("Language-Decoder-GUI-V2.py")).pack(pady=5)


tk.Button(root, text="Open README.txt", width=25, command=open_readme).pack(pady=10)

root.mainloop()