import tkinter as tk
import os
script_dir = os.path.dirname(os.path.abspath(__file__))
launcher_dir = script_dir
letters = [
"a","á","ä","b","c","č","d","ď","dz","dž","e","é","f","g","h","ch",
"i","í","j","k","l","ĺ","ľ","m","n","ň","o","ó","ô","p","q","r","ŕ",
"s","š","t","ť","u","ú","v","w","x","y","ý","z","ž"
]

numbers = [str(i+1) for i in range(len(letters))]

encode_dict = dict(zip(letters, numbers))
decode_dict = dict(zip(numbers, letters))



def encode(text):
    text = text.lower()
    words = text.split(" ")
    encoded_words = []

    for word in words:
        i = 0
        encoded_letters = []

        while i < len(word):

            if word[i:i+2] in ["dz","dž","ch"]:
                encoded_letters.append(encode_dict[word[i:i+2]])
                i += 2
                continue

            letter = word[i]

            if letter in encode_dict:
                encoded_letters.append(encode_dict[letter])

            i += 1

        encoded_words.append("-".join(encoded_letters))

    return " : ".join(encoded_words)


def decode(code):
    words = code.split(" : ")
    decoded_words = []

    for word in words:
        nums = word.split("-")
        letters_word = []

        for n in nums:
            if n in decode_dict:
                letters_word.append(decode_dict[n])

        decoded_words.append("".join(letters_word))

    return " ".join(decoded_words)


def convert():
    text = input_box.get()

    if any(c.isdigit() for c in text):
        result = decode(text)
    else:
        result = encode(text)

    output_box.config(state="normal")
    output_box.delete(0, tk.END)
    output_box.insert(0, result)
    output_box.config(state="readonly")


root = tk.Tk()
root.title("Language Decoder GUI V2")
root.geometry("500x200")

icon_path = os.path.join(launcher_dir, "icons", "L.Decoder.ico")
try:
    root.iconbitmap(icon_path)
except tk.TclError:
    print("Icon not found, continuing without it...")

label1 = tk.Label(root, text="Text or Code:")
label1.pack()

input_box = tk.Entry(root, width=60)
input_box.pack(pady=5)

button = tk.Button(root, text="Convert", command=convert)
button.pack(pady=10)

label2 = tk.Label(root, text="Result:")
label2.pack()

output_box = tk.Entry(root, width=60, state="readonly")
output_box.pack(pady=5)

root.mainloop()